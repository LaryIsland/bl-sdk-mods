# Shield Recharge Timer
### Adds a timer to your HUD that counts the seconds before your shield starts to recharge.

# Changelog

### Shield Recharge Timer v1.0
- Inital Release. (Thanks [RedxYeti](https://github.com/RedxYeti) and [ZetaDaemon](https://github.com/ZetaDaemon))
