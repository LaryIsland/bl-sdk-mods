# Melee Enhancement
### A few tweaks to Zer0 and Krieg to enhance their melee gameplay.

# Changelog

### Melee Enhancement v1.0
- Inital Release.
